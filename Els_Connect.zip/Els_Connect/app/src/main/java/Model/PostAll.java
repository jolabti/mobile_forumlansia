package Model;

import com.google.gson.annotations.SerializedName;

public class PostAll {
    @SerializedName("post_id")
    public String post_id;

    @SerializedName("posting")
    public String posting;

    @SerializedName("waktu")
    public String waktu;

}
