package Response;

import android.util.Log;

import Model.PostModel;

public class JsonResponse {
    public PostModel[] posts;

    public PostModel[] getPosts() {

        return posts;
    }
}