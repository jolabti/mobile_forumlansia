package GSON;

import com.google.gson.annotations.SerializedName;

public class GsonRegister {

    @SerializedName("response")
    public String response;

    @SerializedName("code")
    public String code;

    @SerializedName("message")
    public String message;

}