package GSON;

import com.google.gson.annotations.SerializedName;

public class GSONLogin {

    @SerializedName("message")
    public String message;

    @SerializedName("response")
    public String response;

    @SerializedName("email_resp")
    public String email_resp;

    @SerializedName("id_user")
    public String id_resp;



}
